from src.index import independentFunction
from src.index import check_triangle, print_Prime


if __name__ == "__main__":
    a, b, c = map(int, input().split())
    right_angled(a, b, c):
    n = int(input())
    is_prime(n):
    
    
    IndependentFunction(1)
