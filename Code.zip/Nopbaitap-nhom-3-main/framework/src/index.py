
# HÀM TẠO HÀM ĐỘC LẬP KHÔNG GỌI HÀM KHÁC
def independentFunction(a):
    return (a)

#HÀM GỌI HÀM Foo NÊN KHI TEST BẰNG UNIT CẦN PHẢI MOCK
def functionThatCallOther(a):
    result = foo(a)
    return result
def foo(a):
    return a 


def right_angled(a, b, c):
    if (a*a+b*b==c*c) or (c*c+b*b==a*a) or (a*a+c*c==b*b) :
        return "The triangle is right-angled."
    else:
        return "The triangle is not right-angled."
def check_prime_number(n):
def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True

    
    #Sử dụng vòng lặp while để kiểm tra có tồn tại ước số nào khác không
    for p in range(2, n):
        if n % p == 0:
            flag = 0
            break #Chỉ cần tìm thấy 1 ước số là đủ và thoát vòng lặp
    return flag

def print_Prime(n):
    for i in range(2,n):
        if check_prime_number(i):
            print(i)
